/*
 * SpurtCommerce
 * http://www.spurtcommerce.com
 *
 * Copyright (c) 2022 PICCOSOFT
 * Author piccosoft <support@spurtcommerce.com>
 * Licensed under the MIT license.
 */
import { Map, Record } from 'immutable';

export interface CustomerState extends Map<string, any> {
  customerList: any;
  pagination: any;
  addcustomer: any;
  updatecustomer: any;
  deletecustomer: any;
  detailCustomer: any;

  detailLoading: boolean;
  detailLoaded: boolean;
  detailFailed: boolean;

  listLoading: boolean;
  listLoaded: boolean;
  listFailed: boolean;

  countLoading: boolean;
  countLoaded: boolean;
  countFailed: boolean;

  addLoading: boolean;
  addLoaded: boolean;
  addFailed: boolean;

  updateLoading: boolean;
  updateLoaded: boolean;
  updateFailed: boolean;

  deleteLoading: boolean;
  deleteLoaded: boolean;
  deleteFailed: boolean;

  customersGroupListLoading: boolean;
  customersGroupListLoaded: boolean;
  customersGroupListFailed: boolean;
  customersGroupList: any;
}

export const CustomerStateRecord = Record({
  customerList: {},
  pagination: {},
  addcustomer: {},
  updatecustomer: {},
  deletecustomer: {},
  detailCustomer: {},

  detailLoading: false,
  detailLoaded: false,
  detailFailed: false,
  listLoading: false,
  listLoaded: false,
  listFailed: false,

  countLoading: false,
  countLoaded: false,
  countFailed: false,

  addLoading: false,
  addLoaded: false,
  addFailed: false,

  updateLoading: false,
  updateLoaded: false,
  updateFailed: false,

  deleteLoading: false,
  deleteLoaded: false,
  deleteFailed: false,

  customersGroupListLoading: false,
  customersGroupListLoaded: false,
  customersGroupListFailed: false,
  customersGroupList: []
});
